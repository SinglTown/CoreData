//
//  Person.m
//  CoreData
//
//  Created by lanou3g on 15/12/15.
//  Copyright © 2015年 chuanbao. All rights reserved.
//

#import "Person.h"

@implementation Person

// Insert code here to add functionality to your managed object subclass

@end
