//
//  ViewController.m
//  CoreData
//
//  Created by lanou3g on 15/12/15.
//  Copyright © 2015年 chuanbao. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "Person.h"
@interface ViewController ()

@property (nonatomic,strong)NSManagedObjectContext *context;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //误区:coreData是数据库-->是不正确说法
    /*CoreData 05年 ios5之后发布,主要提供的是ORM功能(对象-关系映射),sqlite是关系型数据库
     coreData在存储数据的时候可以采取以下4种方式:数据库,XML文件,二进制形式,内存的形式(还有一种,自定义类型的形式),默认是采用数据库的存储方式
     
     
     CoreData苹果封装的一个工作在模型层的框架
     优势:1.可以直接存储OC对象,也可以把OC对象直接从以上四种存储文件中取出
         2.相对于数据库繁琐的SQL语句,CoreData不用再写SQL语句
    */
    //数据持久化技术:plist文件,NSUserDefaults,数据库,文件,CoreData
    
    
    //CoreData里面一些重要对象
    //1.NSManagedObjectContext 管理上下文,主要作用是:负责应用程序和数据之间的交互(CoreData任何实际的操作都是通过它来完成)
    //2.NSPersistentStoreCoordinator 连接器(桥梁)主要作用:决定coreData存储的方式,并且连接到具体存储的位置
    //3.NSManagedObject CoreData存取的直接对象
    //4.NSManagedObjectModel 模型实体类
    
    
    
    //1.创建一个NSManagedObjectModel对象(描述实体模型)
    NSManagedObjectModel *model = [NSManagedObjectModel mergedModelFromBundles:nil];
    //2.桥梁(连接器)
    NSPersistentStoreCoordinator *storeCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
    //存储的路径
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    path = [path stringByAppendingPathComponent:@"data"];
    //连接路径
    //第一参数:存储的类型
    //第三个参数:路径
    NSError *error = nil;
    [storeCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:[NSURL fileURLWithPath:path] options:nil error:&error];
    
    //3.初始化管理上下文
    self.context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    //上下文管理 连接器
    self.context.persistentStoreCoordinator = storeCoordinator;
    
    
    
    
}
#pragma mark - 点击事件
- (IBAction)clickButtonAction:(id)sender {
    
    NSInteger i = arc4random()%100;
    NSManagedObject *aPerson = [NSEntityDescription insertNewObjectForEntityForName:@"Person" inManagedObjectContext:self.context];
    //通过KVC的方式赋值
    NSString *nameString = [NSString stringWithFormat:@"name%ld",i];
    [aPerson setValue:nameString forKey:@"name"];
    NSNumber *ageNumber = [NSNumber numberWithInteger:i];
    [aPerson setValue:ageNumber forKey:@"age"];
    //通过上面几步并没有真正把aperson保存到数据库,而是暂时把它保存到context里面
    //判断如果context发生了改变,则进行保存操作
    if ([self.context hasChanges]) {
        [self.context save:nil];
    }
}
- (IBAction)searchButtonAction:(id)sender {
    //创建请求对象,并且指明所有的数据类型
    NSFetchRequest *request = [[NSFetchRequest alloc] initWithEntityName:@"Person"];
    NSArray *objcArray = [self.context executeFetchRequest:request error:nil];
    for (NSManagedObject *object in objcArray) {
        NSLog(@"%@,%@",[object valueForKey:@"name"],[object valueForKey:@"age"]);
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
